#!/bin/bash

\rm -rf MadTMP

\rm -rf `cat MGfiles.list`

